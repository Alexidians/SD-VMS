import os
import json
import subprocess
import easygui
import uuid
from datetime import datetime
import requests
import zipfile

VM_DIR = "VMs"
QEMU_DIR = "qemu"  # Relative path to your QEMU directory
if not os.path.exists(QEMU_DIR):

    # URL of the ZIP file
    url = "https://alexidians.com/SD-VMS/Requirements/QEMU/qemu.zip"

    # Define paths
    zip_path = "qemu.zip"
    extract_folder = "qemu"
    
    # Download the ZIP file
    print("Downloading ZIP file...")
    response = requests.get(url, stream=True)
    with open(zip_path, "wb") as file:
        for chunk in response.iter_content(chunk_size=8192):
            file.write(chunk)
    print("Download complete.")
    
    # Extract ZIP file
    print("Extracting files...")
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(extract_folder)
    print(f"Files extracted to '{extract_folder}'.")
    
    # Cleanup (optional)
    os.remove(zip_path)
    print("ZIP file removed.")

def create_vm():
    """Create a new VM configuration with default settings."""
    name = input("Enter VM name: ").strip()
    vm_path = os.path.join(VM_DIR, name)
    os.makedirs(vm_path, exist_ok=True)

    # Default settings
    cpu = 2  # Default CPU
    ram = 2048  # Default RAM (2 GB)
    use_kvm = True  # Default KVM support
    arch = "x86_64"  # Default architecture (x86_64)
    
    # Disks - Use EasyGUI to select files or create new disks
    disks = []
    while True:
        disk = easygui.buttonbox(
            "Do you want to add an existing disk or create a new one?",
            choices=["Add existing disk", "Create new disk", "Done"]
        )

        if disk == "Add existing disk":
            new_disk = easygui.fileopenbox(
                title="Select Disk File", 
                filetypes=["*.vmdk", "*.vdi", "*.vhd", "*.hdd", "*.qed", "*.qcow", "*.qcow2", "*.vhdx"]
            )
            if new_disk:
                disks.append(new_disk)
            else:
                print("No disk selected.")
        elif disk == "Create new disk":
            disk_type = easygui.choicebox("Choose the disk type:", choices=["vmdk", "vdi", "vhd", "hdd", "qed", "qcow", "qcow2", "vhdx"])
            disk_size = input("Enter the disk size in MB (e.g., 1024 for 1GB): ").strip()
            if disk_size:
                disk_size = int(disk_size)
                disk_path = os.path.join(vm_path, f"{name}_disk.{disk_type}")
                create_disk(disk_path, disk_type, disk_size)
                disks.append(disk_path)
            else:
                print("Invalid size entered.")
        elif disk == "Done":
            break

    # Display settings (defaults)
    resolution = "1920x1080"
    graphics = "std"  # Default graphics type

    # Networking (defaults)
    net_type = "user"  # Default network type
    net_device = "e1000"  # Default network device
    net_id = "net0"  # Default network ID

    # Save configuration
    vm_config = {
        "name": name,
        "cpu": {
            "cores": cpu,
            "name": None
        },
        "boot": {
           "order": None
        },
        "keyboard": {
            "layout": None
        },
        "ram": ram,
        "arch": arch,
        "use_kvm": use_kvm,
        "disks": disks,
        "display": {
            "resolution": resolution,
            "graphics": graphics,
            "gtk": {
                "tabs": False
            }
        },
        "network": {
            "type": net_type,
            "device": net_device,
            "id": net_id
        }
    }

    with open(os.path.join(vm_path, "vm.json"), "w") as f:
        json.dump(vm_config, f, indent=4)

    print(f"VM '{name}' created with default settings!")

def create_disk(disk_path, disk_type, disk_size):
    """Create a new disk image of the specified type and size."""
    # Command to create the disk image
    disk_format = {
        "vmdk": "vmware",
        "vdi": "vdi",
        "vhd": "vhd",
        "hdd": "raw",
        "qed": "qed",
        "qcow": "qcow",
        "qcow2": "qcow2",
        "vhdx": "vhdx"
    }.get(disk_type, "qcow2")  # Default to qcow2 if the type is unknown

    # QEMU command to create the disk
    qemu_cmd = [
        os.path.join(QEMU_DIR, "qemu-img"), "create", 
        "-f", disk_format, disk_path, f"{disk_size}M"
    ]
    
    try:
        subprocess.run(qemu_cmd, check=True)
        print(f"Disk {disk_path} created successfully!")
    except subprocess.CalledProcessError as e:
        print(f"Error creating disk {disk_path}: {e}")

def load_vm(name):
    """Load an existing VM configuration."""
    vm_path = os.path.join(VM_DIR, name, "vm.json")

    if not os.path.exists(vm_path):
        print("VM not found!")
        return None

    with open(vm_path, "r") as f:
        return json.load(f)

def generate_timestamp_with_uuid():
    # Get the current date and time
    current_time = datetime.now().strftime('%Y:%m:%d %H:%M')

    # Generate a random UUID string (without hyphens)
    random_uuid = str(uuid.uuid4()).replace('-', '')

    # Combine the timestamp with the UUID
    return f"{current_time}_{random_uuid}"

def start_vm(name):
    """Start the VM using the qemu command."""
    vm = load_vm(name)
    if not vm:
        return

    # Prepare qemu command with necessary options
    qemu_command = [
        os.path.join(QEMU_DIR, "qemu-system-x86_64"),  # Adjust if using a different architecture
        "-m", str(vm['ram']),  # Set RAM size
        "-smp", str(vm['cpu']["cores"]),  # Set CPU cores
        #"-no-shutdown", # Keep QEMU running after the VM is shut down
        #"-accel", "tcg",
    ]
    qemu_command.extend(["-capture", "filename=" + VM_DIR + "/" + name + "/" + generate_timestamp_with_uuid() + ".mp4"])
    machine_opts = ""
    if vm.get("motherboard", {"chipset": None})["chipset"]:
        if machine_opts != "":
            machine_opts += ","
        machine_opts += "type=" + vm["motherboard"]["chipset"]
    if vm.get("motherboard", {"tpm": False})["tpm"]:
        qemu_command.extend(["-device", "tpm-tis"])
    if vm.get("motherboard", {"I/O_APIC": True})["I/O_APIC"]:
        qemu_command.extend(["-ioapic"])
    if vm.get("motherboard", {"HardwareClockInUTCTime": True})["HardwareClockInUTCTime"]:
        qemu_command.extend(["-rtc", "base=utc"])
    if vm.get("motherboard", {"EFI": False})["EFI"]:
        if os.path.exists("files/bios/OVMF.fd"):
            qemu_command.extend(["-bios", "files/bios/OVMF.fd"])
        else:
            print("ERROR: EFI bios file not found. Please put OVMF.fd in files/bios/OVMF.fd")
    
    if vm.get("motherboard", {"SecureBoot": False})["SecureBoot"]:
        print("NOTE: Secureboot is not supported and is not being enabled. this is a placeholder for later updates.")
        # qemu_command.extend(["-secureboot"])
    if vm.get("motherboard", {"USBTablet": False})["USBTablet"]:
        qemu_command.extend(["-device", "usb-tablet"])
    if vm.get("pae-nx", False):
        qemu_command.extend(["-pae"])
    if vm["display"].get("gtk", {"tabs": False})["tabs"]:
        qemu_command.extend(["-display", "gtk,show-tabs=on"])
    if vm.get("console", {"enabled": False})["enabled"]:
        qemu_command.extend(["-monitor", "stdio"])
        if vm["console"]["virtio-balloon"]:
            qemu_command.extend(["-device", "virtio-balloon"])
    if vm.get("qmp", {"enabled": False})["enabled"]:
        qemu_command.extend(["-qmp", "tcp:localhost:" + vm["qmp"]["port"] + ",server,nowait"])
    if vm["cpu"]["name"]:
        qemu_command.extend(["-cpu", vm["cpu"]["name"]])
    bootopts = ""
    if vm["boot"]["order"]:
        if bootopts != "":
            bootopts += ","
        bootopts += "order=" + vm["boot"]["order"]
    if True:
        if bootopts != "":
            bootopts += ","
        bootopts += "splash=" + os.path.abspath("files/images/superdiamond.jpg") + ",splash-time=10000"
    if bootopts != "":
        qemu_command.extend(["-boot", bootopts])
    if vm["display"].get("video_memory", None):
        qemu_command.extend(["-device", "virtio-vga,ram_size=" + vm["display"]["video_memory"]])
    if vm["keyboard"]["layout"]:
        qemu_command.extend(["-k", vm["keyboard"]["layout"]])
    if vm.get("vnc", {"enabled": False})["enabled"]:
        if vm["vnc"]["password"]:
            qemu_command.extend(["-vnc", f":{vm['vnc']['port']},password=on"])
        else:
            qemu_command.extend(["-vnc", f":{vm['vnc']['port']}"])
    if vm.get("replay", {"mode": "none"})["mode"] != "none":
        if not os.path.exists( os.path.join(VM_DIR, name, "replays.qcow2")):
            create_disk(os.path.join(VM_DIR, name, "replays.qcow2"), "qcow2", 2048)
        qemu_command.extend(["-icount","shift=auto,rr=" + vm["replay"]["mode"] + ",rrfile=" + vm["replay"]["file"]])
        qemu_command.extend(["-net","none","-drive","file=" + os.path.join(VM_DIR, name, "replays.qcow2") + ",if=none,id=rr"])
    
    # Add disk options for each disk in the list
    ide_enabled = False
    for diskobj in vm['disks']:
        if type(diskobj) == str:
            disk = diskobj
            disktype = "default"
        else:
            disk = diskobj["path"]
            disktype = diskobj["type"] # usb, sata, ide, default
        # Determine the format based on the disk file extension
        if disk.endswith(".vmdk"):
            disk_format = "vmdk"
        elif disk.endswith(".vdi"):
            disk_format = "vdi"
        elif disk.endswith(".vhd"):
            disk_format = "vhd"
        elif disk.endswith(".hdd"):
            disk_format = "raw"
        elif disk.endswith(".qed"):
            disk_format = "qed"
        elif disk.endswith(".qcow"):
            disk_format = "qcow"
        elif disk.endswith(".qcow2"):
            disk_format = "qcow2"
        elif disk.endswith(".vhdx"):
            disk_format = "vhdx"
        elif disk.endswith(".iso"):  # Handle ISO files explicitly
            qemu_command.extend(["-cdrom", disk])  # Add ISO as a CD-ROM drive
            continue  # Skip to the next disk
        
        else:
            disk_format = "qcow2"  # Default format if type is not recognized
        
        if ["usb", "sata", "ide", "default"].count(disktype) == 0:
            print("Invalid Disk type: " + disktype)
            print("for disk: " + disk)
            print("Defaulting to default")
            disktype = "default"
        
        diskuuid = "UUID_SDDISC_" + str(uuid.uuid4())
        if disktype == "default":
            qemu_command.extend(["-drive", f"file={disk},format={disk_format},id={diskuuid}"])
        else:
            qemu_command.extend(["-drive", f"file={disk},format={disk_format},if=none,id={diskuuid}"])
        usb_enabled = False
        removablestr = ""
        if diskobj.get("removable", True):
            removablestr = ",removable=on"

        if disktype == "usb":
            #if not vm["controllers"]["usb"]["enabled"]:
                #print("ERROR: USB is not enabled. skipping the drive.")
                #continue
                #qemu_command.extend(["-usb"])
            if not usb_enabled:
                qemu_command.extend(["-device", "usb-ehci"])
                usb_enabled = True
            qemu_command.extend(["-device", "usb-storage,drive=" + diskuuid + removablestr])
        elif disktype == "sata":
            #if not vm["controllers"]["sata"]["enabled"]:
                #print("ERROR: SATA is not enabled. skipping the drive.")
                #continue
                #qemu_command.extend(["-device", "piix3"])
            qemu_command.extend(["-device", "sata-hd,drive=" + diskuuid + removablestr])
        elif disktype == "ide":
            #if not vm["controllers"]["ide"]["enabled"]:
                #print("ERROR: IDE is not enabled. skipping the drive.")
                #continue
                #qemu_command.extend(["-device", "piix3"])
            qemu_command.extend(["-device", "ide-hd,drive=" + diskuuid + removablestr])

    # Display settings (customizable)
    qemu_command.extend([
        "-vga", "std",  # Graphics settings (can be changed based on display configuration)
        "-netdev", f"type={vm['network']['type']},id=net0" #{vm["network"]["device"]}",  # Network settings
        #"-device", "virtio-net,netdev=net0"  # Example network device setup
    ])

    print("Generated Command: ", qemu_command)
    print("Starting VM...")
    try:
        subprocess.run(qemu_command, check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error starting VM: {e}")
    else:
        print(f"VM '{name}' started successfully!")

def modify_vm(name):
    """Modify an existing VM configuration."""
    vm = load_vm(name)
    if not vm:
        return

    while True:
        print(f"\nCurrent configuration for {name}:")
        print(json.dumps(vm, indent=4))

        print("\nModify settings (choose an option):")
        print("1. Modify CPU number")
        print("2. Modify RAM size")
        print("3. Modify architecture")
        print("4. Modify display settings")
        print("5. Modify network settings")
        print("6. Add/Modify disks")
        print("7. Remove disk")
        print("8. Start VM")
        print("9. Modify CPU Name")
        print("10. Modify Boot Order")
        print("11. Modify Keyboard Layout")
        print("12. Manage VNC settings")
        print("13. Manage Replay Settings")
        print("14. Toggle GTK Tabs")
        print("15. Manage QEMU Console Settings")
        print("16. QMP Settings")
        print("17. Motherboard Settings")
        print("18. Toggle PAE/NX")
        print("19. Set Video Memory")
        #print("20. Toggle Screen Recording")
        print("Type 'Save' to save the configuration")
        print("0. Exit")
        choice = input("Choose an option: ").strip()

        if choice == "1":
            cpu = input(f"Enter number of CPUs (current: {vm['cpu']}): ").strip()
            if cpu:
                vm['cpu']["cores"] = int(cpu)
        elif choice == "2":
            ram = input(f"Enter RAM (MB) (current: {vm['ram']}): ").strip()
            if ram:
                vm['ram'] = ram
        elif choice == "3":
            arch = input(f"Enter architecture (current: {vm['arch']}): ").strip()
            if arch:
                vm['arch'] = arch
        elif choice == "4":
            resolution = input(f"Enter display resolution (current: {vm['display']['resolution']}): ").strip()
            if resolution:
                vm['display']['resolution'] = resolution
            graphics = input(f"Enter graphics type (current: {vm['display']['graphics']}): ").strip()
            if graphics:
                vm['display']['graphics'] = graphics
        elif choice == "5":
            net_type = input(f"Enter network type (current: {vm['network']['type']}): ").strip()
            if net_type:
                vm['network']['type'] = net_type
            net_device = input(f"Enter network device (current: {vm['network']['device']}): ").strip()
            if net_device:
                vm['network']['device'] = net_device
        elif choice == "6":
            # Allow adding or modifying disks
            disks = vm['disks']
            print("Current disks:")
            for idx, disk in enumerate(disks, 1):
                print(f"{idx}. {disk}")
            print("0. Add a new disk")
            disk_choice = input("Choose a disk to modify (or 0 to add a new one): ").strip()
            if disk_choice == "0":
                new_disk = easygui.fileopenbox(
                    title="Select Disk File", 
                    filetypes=["*.vmdk", "*.vdi", "*.vhd", "*.hdd", "*.qed", "*.qcow", "*.qcow2", "*.vhdx"]
                )
                if new_disk:
                    disks.append(new_disk)
                    print("Disk added.")
            elif disk_choice.isdigit() and 1 <= int(disk_choice) <= len(disks):
                # Modify selected disk
                diskobj = disks[int(disk_choice) - 1]
                if type(diskobj) == str:
                    diskobj = {
                        "path": diskobj,
                        "type": "default"
                    }
                while True:
                    print("Disk Settings:")
                    print("1. Change disk path")
                    print("2. Change Disk Type")
                    print("3. Toggle Removable")
                    print("0. Exit")
                    disk_choice = input("Choose an option: ").strip()
                    if disk_choice == "1":
                        new_disk = easygui.fileopenbox(
                            title="Select New Disk File", 
                            filetypes=["*.vmdk", "*.vdi", "*.vhd", "*.hdd", "*.qed", "*.qcow", "*.qcow2", "*.vhdx"]
                        )
                        if new_disk:
                            diskobj["path"] = new_disk
                            print("Disk modified.")
                    elif disk_choice == "2":
                        disk_type = easygui.choicebox("Choose the disk type:", choices=["usb", "sata", "ide", "default"])
                        if disk_type:
                            diskobj["type"] = disk_type
                            print("Disk type has been changed")
                    elif disk_choice == "3":
                        diskobj["removable"] = not diskobj.get("removable", True)
                        print(f"Disk {'is' if diskobj['removable'] else 'is not'} removable.")
                    elif disk_choice == "0":
                        disks[int(disk_choice) - 1] = diskobj
                        break
        elif choice == "7":
            # Remove disk
            disks = vm['disks']
            print("Current disks:")
            for idx, disk in enumerate(disks, 1):
                print(f"{idx}. {disk}")
            disk_choice = input("Choose a disk to remove: ").strip()
            if disk_choice.isdigit() and 1 <= int(disk_choice) <= len(disks):
                removed_disk = disks.pop(int(disk_choice) - 1)
                print(f"Disk '{removed_disk}' removed.")
            else:
                print("Invalid disk choice.")
        elif choice == "8":
            start_vm(name)  # Start the VM with the configured settings
        elif choice == "9":
            cpu_name = input(f"Enter CPU Name (current: {vm['cpu']['name']}): ").strip()
            if cpu_name:
                vm['cpu']['name'] = cpu_name
            else:
                vm['cpu']['name'] = None
        elif choice == "10":
            boot_order = input(f"Enter Boot Order (current: {vm['boot']["order"]}) d=CD-Rom/ISO,c=HDD,n=Network (PXE),a=Floppy: ").strip()
            if boot_order:
                vm['boot']["order"] = boot_order
            else:
                vm['boot']["order"] = None
        elif choice == "11":
            keyboard_layout = input(f"Enter Keyboard Layout (current: {vm['keyboard']["layout"]}): ").strip()
            if keyboard_layout:
                vm['keyboard']["layout"] = keyboard_layout
            else:
                vm['keyboard']["layout"] = None
        elif choice == "12":
            if not vm.get('vnc'):
                vm['vnc'] = {
                    'enabled': False,
                    'password': False,
                    'port': '1'
                }
            while True:
                print("\nVNC Settings")
                print("1. Toggle VNC")
                print("2. Toggle Password")
                print("3. Set VNC Port")
                print("0. Exit")
                vnc_choice = input("Choose an option: ").strip()
                if vnc_choice == "1":
                    vm['vnc']['enabled'] = not vm['vnc']['enabled']
                    print(f"VNC {'enabled' if vm['vnc']['enabled'] else 'disabled'}.")
                elif vnc_choice == "2":
                    vm['vnc']['password'] = not vm['vnc']['password']
                    print(f"VNC password {'enabled' if vm['vnc']['password'] else 'disabled'}.")
                elif vnc_choice == "3":
                    vnc_port = input(f"Enter VNC Port (current: {vm['vnc']['port']}): ").strip()
                    if vnc_port:
                        vm['vnc']['port'] = vnc_port
                elif vnc_choice == "0":
                    break
        elif choice == "13":
            if not os.path.exists( os.path.join(VM_DIR, name, "replays.qcow")):
                create_disk(os.path.join(VM_DIR, name, "replays.qcow"), "qcow2", 2048)
            if not vm.get('replay'):
                vm['replay'] = {
                    'mode': "none",
                    'file': "replay"
                }
            while True:
                print("1. Set To Recording Mode")
                print("2. Set To Replay Mode")
                print("3. Disable Replay Mode")
                print("4. Set Replay File")
                print("0. Exit")
                replay_choice = input("Choose an option: ").strip()
                if replay_choice == "1":
                    vm['replay']['mode'] = "record"
                    print("Replay mode set to record.")
                elif replay_choice == "2":
                    vm['replay']['mode'] = "replay"
                    print("Replay mode set to replay.")
                elif replay_choice == "3":
                    vm['replay']['mode'] = "none"
                    print("Replay mode disabled.")
                elif replay_choice == "4":
                    replay_file = input(f"Enter Replay File (current: {vm['replay']['file']}): ").strip()
                    if replay_file:
                        vm['replay']['file'] = replay_file
                elif replay_choice == "0":
                    break
        elif choice == "14":
            if not vm.get('display'):
                vm['display'] = {
                    'gtk': {
                        'tabs': False
                    }
                }
            vm['display']['gtk']['tabs'] = not vm['display']['gtk']['tabs']
            print(f"GTK Tabs {'enabled' if vm['display']['gtk']['tabs'] else 'disabled'}.")
        elif choice == "15":
            if not vm.get('console'):
                vm['console'] = {
                    'enabled': False,
                    'virtio-balloon': False
                }
            while True:
                print("\nQEMU Console Settings")
                print("1. Toggle QEMU Console")
                print("2. Toggle Virtio Balloon")
                print("0. Exit")
                console_choice = input("Choose an option: ").strip()
                if console_choice == "1":
                    vm['console']['enabled'] = not vm['console']['enabled']
                    print(f"QEMU Console {'enabled' if vm['console']['enabled'] else 'disabled'}.")
                elif console_choice == "2":
                    vm['console']['virtio-balloon'] = not vm['console']['virtio-balloon']
                    print(f"Virtio Balloon {'enabled' if vm['console']['virtio-balloon'] else 'disabled'}.")
                elif console_choice == "0":
                    break
        elif choice == "16":
            if not vm.get('qmp'):
                vm['qmp'] = {
                    'enabled': False,
                    'port': '4444'
                }
            while True:
                print("\nQMP Settings")
                print("1. Toggle QMP")
                print("2. Set QMP Port")
                print("0. Exit")
                qmp_choice = input("Choose an option: ").strip()
                if qmp_choice == "1":
                    vm['qmp']['enabled'] = not vm['qmp']['enabled']
                    print(f"QMP {'enabled' if vm['qmp']['enabled'] else 'disabled'}.")
                elif qmp_choice == "2":
                    qmp_port = input(f"Enter QMP Port (current: {vm['qmp']['port']}): ").strip()
                    if qmp_port:
                        vm['qmp']['port'] = qmp_port
                elif qmp_choice == "0":
                    break
        elif choice == "17":
            if not vm.get('motherboard'):
                vm['motherboard'] = {
                    'chipset': None,
                    'tpm': False,
                    "I/O_APIC": True,
                    "HardwareClockInUTCTime": True,
                    "EFI": False,
                    "SecureBoot": False,
                    "USBTablet": False
                }
            while True:
                print("\nMotherboard Settings")
                print("1. Toggle TPM")
                print("2. Set Chipset")
                print("3. Toggle I/O APIC")
                print("4. Toggle Hardware Clock in UTC Time")
                print("5. Toggle EFI")
                print("6. Toggle Secure Boot")
                print("7. Toggle USB Tablet")
                print("0. Exit")
                motherboard_choice = input("Choose an option: ").strip()
                if motherboard_choice == "1":
                    vm['motherboard']['tpm'] = not vm['motherboard']['tpm']
                    print(f"Motherboard {'tpm' if vm['motherboard']['tpm'] else 'disabled'}.")
                elif motherboard_choice == "2":
                    chipset_type = input(f"Enter Chipset (current: {vm['motherboard']['chipset']}): ").strip()
                    if chipset_type:
                        vm['motherboard']['chipset'] = chipset_type
                    else:
                        vm['motherboard']['chipset'] = None
                elif motherboard_choice == "3":
                    vm['motherboard']['I/O_APIC'] = not vm['motherboard']['I/O_APIC']
                    print(f"I/O APIC {'enabled' if vm['motherboard']['I/O_APIC'] else 'disabled'}.")
                elif motherboard_choice == "4":
                    vm['motherboard']['HardwareClockInUTCTime'] = not vm['motherboard']['HardwareClockInUTCTime']
                    print(f"Hardware Clock in UTC Time {'enabled' if vm['motherboard']['HardwareClockInUTCTime'] else 'disabled'}.")
                elif motherboard_choice == "5":
                    vm['motherboard']['EFI'] = not vm['motherboard']['EFI']
                    print(f"EFI {'enabled' if vm['motherboard']['EFI'] else 'disabled'}.")
                elif motherboard_choice == "6":
                    vm['motherboard']['SecureBoot'] = not vm['motherboard']['SecureBoot']
                    print(f"Secure Boot {'enabled' if vm['motherboard']['SecureBoot'] else 'disabled'}.")
                elif motherboard_choice == "7":
                    vm['motherboard']['USBTablet'] = not vm['motherboard']['USBTablet']
                    print(f"USB Tablet Pointing {'enabled' if vm['motherboard']['USBTablet'] else 'disabled'}.")
                elif motherboard_choice == "0":
                    break
        elif choice == "18":
            if not vm.get('pae-nx'):
                vm['pae-nx'] = False
            vm['pae-nx'] = not vm['pae-nx']
            print(f"PAE/NX {'enabled' if vm['pae-nx'] else 'disabled'}.")
        elif choice == "19":
            video_memory = input(f"Enter Video Memory (M = MB, G = GB) (current: {vm['display'].get("video_memory", None)}): ").strip()
            if video_memory:
                vm['display']['video_memory'] = video_memory
            else:
                vm['display']['video_memory'] = None
        elif choice == "20":
            if not vm.get('screen-recording'):
                vm['screen-recording'] = False
            vm['screen-recording'] = not vm['screen-recording']
            print(f"Screen Recording {'enabled' if vm['screen-recording'] else 'disabled'}.")

        elif choice == "Save":
            with open(os.path.join(VM_DIR, name, "vm.json"), "w") as f:
                json.dump(vm, f, indent=4)
        elif choice == "0":
            break  # Exit the modify loop
        

    # Save the modified configuration
    with open(os.path.join(VM_DIR, name, "vm.json"), "w") as f:
        json.dump(vm, f, indent=4)

    print(f"VM '{name}' modified successfully!")

def main():
    """Main function to interact with the user."""
    while True:
        print("\nVM Management")
        print("1. Create a new VM")
        print("2. Modify an existing VM")
        print("3. Exit")
        choice = input("Choose an option: ").strip()

        if choice == "1":
            create_vm()
        elif choice == "2":
            vm_name = input("Enter VM name to modify: ").strip()
            modify_vm(vm_name)
        elif choice == "3":
            break
        else:
            print("Invalid option. Please try again.")

if __name__ == "__main__":
    main()
