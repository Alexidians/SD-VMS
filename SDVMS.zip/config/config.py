HYPERVISOR = "VirtualBox"
#Can be one of these:
#Supported: Qemu
#In Development (Not Recommended): Hyper-V, VirtualBox

QEMU_INSTALL_DIR = "qemu" # Path to Qemu install directory (default install dir is qemu)
VIRTUALBOX_VBOXMANAGE_PATH = "C:/Program Files/Oracle/VirtualBox/VBoxManage.exe" # Path to VBoxManage.exe For VirtualBox Hypervisor